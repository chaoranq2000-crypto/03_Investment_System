# R5 Patch 12 后续补丁包

文件说明：

- `r5_after_patch12_codex_tasks.patch`：可提交给 Git 的统一 diff，只新增 Codex 任务卡。
- `codex_tasks/r5_after_patch12/R5_PATCH1_12_COMPLETION_REVIEW.md`：本轮检查报告。
- `codex_tasks/r5_after_patch12/APPLY_ORDER.md`：任务执行顺序。
- `codex_tasks/r5_after_patch12/R5_PATCH_13_*.md` 至 `R5_PATCH_24_*.md`：下一阶段任务卡。

建议先执行 Patch 13，再执行 14-20。不要跳过格式恢复。
